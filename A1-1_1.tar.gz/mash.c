#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#define MAXSTR 65
#define MAXFILE 64
#define ARGCNT 5

int main(int argc, char * argv[])
{
	char cmd1[MAXSTR];
	printf("mash-1>");
	scanf("%65[^\n]", cmd1);
	
	while(getchar() != '\n');

	char cmd2[MAXSTR];
	printf("mash-2>");
	scanf("%65[^\n]", cmd2);

	while(getchar() != '\n');

	char cmd3[MAXSTR];
	printf("mash-3>");
	scanf("%65[^\n]", cmd3);

	while(getchar() != '\n');

	char file[MAXFILE];
	printf("file>");
	scanf("%65[^\n]", file);

	while(getchar() != '\n');

	int p1 = fork();
	clock_t start = clock();
	if(p1==0){
		//printf("-----CMD 2: %s------\n", cmd2);
		//clock_t start2 = clock();
		runCmd(cmd2, file, 2);
		//clock_t end2 = clock();
		//printf("Took %d\n", (end2-start2));
	}
	if(p1>0){
		int p2 = fork();
		if(p2 == 0){
			//printf("-----CMD 3: %s------\n", cmd3);
			//clock_t  start3 = clock();
			runCmd(cmd3, file, 3);
			//clock_t end3 = clock();
			//printf("Took %d\n", (end3-start3));
		}
		if(p2>0){
			int p3 = fork();
			if(p3 == 0){
				//printf("-----CMD 1: %s------\n", cmd1);
				//clock_t start1 = clock();
				runCmd(cmd1, file, 1);
				//clock_t end1 = clock();
				//printf("Took %d\n", (end1 - start1));
			}
			if(p3 >0){
				while(wait(NULL)>0);
				printf("--------------------------------------------------------------------------------");
				printf("Children process IDs: %i %i %i\n", p1, p2, p3);
			}
		}
	}
	clock_t end = clock();
	printf("Total elapsed time:%dms\n", (end-start));

	//runCmd(cmd1);
	
	//printf("char %lu=%d\n", strlen(cmd), cmd[strlen(cmd)]);
	
	return 0;
}

void runCmd(char cmd[], char file[], int cmdNum){
	char ** args = malloc(sizeof(char*) * (ARGCNT+2));
	
	//char string[] = "hello there";
	char * token = strtok(cmd, " ");
	int i = 0;	
	while(token != NULL){
		//printf("%s\n", token);
		*(args+i) = token;
		token = strtok(NULL, " ");
		i++;
	}
	*(args+i) = file;
	//*(args) = cmd;
	
	//printf("i=%d args[i]=%s\n",i, args[i]);

	int status = execvp(args[0], args);
	if(status == -1) printf("CMD%i: [SHELL %i] STATUS CODE=-1", cmdNum, cmdNum);
}
